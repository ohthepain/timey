# Human-input protocol v1

This reference defines the standalone shared core. Read it when handling native human-input responses, grilling assessments, projected human obligations, guarded dispatch or Quick fix v2. The helper validates structure and freshness; the agent remains responsible for actual authorization, answer coverage, dependencies and evidence applicability.

The full human table and consuming-project adapters are later work. Use text commands in the selected skill: `issues human [ID]`, `issues ID answer REQUEST_ID`, `issues ID grill [REQUEST_ID]`, `issues ID defer REQUEST_ID`, `issues ID resume REQUEST_ID`. These are agent routing conventions, not shell commands. Resolve a full issue ID and exact source key before applying a response. Projected sources use their owner handler for answers; shared apply stores disposition only. Answering records input only. Continue only when the user explicitly chooses the exact next operation and its ordinary authorization and gates pass.

Use this skill's own `scripts/human-input.mjs` and adjacent manifest. Run capabilities first, require protocol major 1 and needed actions, then read with a trusted context file outside the queue. No sibling skill, npm install, source checkout or network is needed at runtime. Missing/incompatible helper is a dispatch blocker; diagnostic listing may still explain the problem. Capability hashes are integrity evidence, not signatures or authorization.

For a new request, construct its source-missing guard from the current issue's canonical project root, full ID, report/configuration/policy digests, exact saved state, operation and candidate/target context; set source_revision and expected_status to null. Read returns a grilling guard as `issues[].grilling.guard` for assessment updates. Native additions begin unresolved; resolve them separately with current review. The helper supports full typed actions only, not arbitrary patches. Existing invalid metadata requires an explicit reviewed repair before guarded writes.

## 2. Exact v1 additive stored schema

Existing report fields, custom lifecycle, original prose, unknown YAML keys/comments, human_checks and project overrides remain authoritative. New metadata is opt-in on selected/reviewed reports. Missing metadata yields `unassessed`, not "never grilled", "completed", or a blanket blocker. Listing never backfills.

Use these normative JSON-compatible YAML shapes. String IDs are nonempty slugs matching `[a-z][a-z0-9-]{0,63}`; UUID-derived slugs are allowed. Never use array position, title, timestamp, or a mutable prompt as identity. Request IDs are unique within the report forever; retired IDs remain history, never recycled. References are nonempty stable report anchors, document anchors, or actual conversation/event pointers. A reference string is evidence navigation, not proof of its content. No access-bearing URLs or secrets in projections.

```yaml
human_input:
  version: 1
  scopes:
    - id: main
      revision: 1
      basis_refs: ["docs/plans/example.md#agreed-scope"]
  requests:
    - id: scope-choice
      kind: decision                # clarification | decision | grilling
      prompt: "Which scope should the implementation cover?"
      expected: "A bounded scope decision and rationale"
      scope: {id: main, revision: 1}
      prerequisites: []
      blocks:
        - {operation: implement, scope_ids: [main]}
        - {operation: merge, scope_ids: [main]}
        - {operation: record-integration, scope_ids: [main]}
      status: pending               # pending | in-progress | deferred | resolved
      events: []
      outcome: null
  overlays: []
```

`version`, `scopes`, `requests`, `overlays` are required when human_input exists (empty lists permitted). `scopes[].revision` is a positive integer, increased by a reviewed material change; `basis_refs` is a nonempty list. Scope IDs are stable. Scope revision is not a commit hash or report-content hash. Any referenced scope must exist; old requests may refer to a historical revision documented in history. IDs and references preserve history when wording changes.

`blocks[].operation` is one of `investigate`, `prototype`, `implement`, `verify`, `commit`, `advance`, `merge`, `record-integration`, `accept`, `close`. `scope_ids` is a nonempty list of affected scopes. `advance` gates also require `target_state` containing the exact configured saved state. `scope_ids: ["*"]` explicitly covers all scope, never inferred from a missing list. Empty blocks means optional, not implicitly gating. Unknown operations/invalid scopes are diagnostic blockers; do not silently ignore them. A dispatcher expands Quick fix to its intended implement/verify/commit steps and lifecycle transitions, rather than inventing a new unrestricted operation.

Prerequisites are an ordered list of `{source_key, condition}`; conditions are `resolved`, `passed`, `work-ready`, `evidence-ready`, `candidate-ready`. Resolve source_key through the current model or trusted adapter fact, never a free-form boolean in the report. Unknown, missing, stale or failed prerequisites yield upcoming/unknown availability, not satisfaction. Cycles are invalid; preserve diagnostic source identities. Prerequisites determine when the human can usefully act; an unavailable request can STILL block dependent work. They never postpone enforcement of its blocks.

Every event has `{id, type, at, actor, summary, evidence_refs}`. Types: `started`, `partial`, `deferred`, `resumed`, `answered`, `delegated`, `reopened`, `scope-reviewed`. Actor: `human` or `agent`. at is an ISO timestamp, not concurrency authority. summary and evidence_refs are nonempty; event IDs unique within report. Events append; correction is a new event. For deferred requests the latest deferred event gives reason and optional `resume_after` ISO time; time expiry makes it discoverable, not resolved or a waiver. Resume changes status to pending/in-progress through an explicit targeted response. Preserve unanswered fragments as partial events.

A resolved request requires:

```yaml
outcome:
  type: human-answer                # human-answer | delegated-decision
  summary: "Concrete answer and covered question fragments"
  evidence_refs: ["report.md#saved-answer"]
  actor: human                      # delegated-decision requires agent
  scope: {id: main, revision: 1}
  covers: ["scope-choice"]           # exactly this request; shared evidence may be reused elsewhere
  delegation: null
```

Delegated-decision is allowed only for kind decision or clarification when all remaining questions are suitable choices (agent reviews this). It requires `actor: agent`, plus delegation `{authorization_ref, bounds, rationale}` with nonempty strings. The actual choice belongs in summary. Permission to decide must come from the human; `autonomy: go` can support an already defined bounded choice only after reviewing its meaning and source. It does not constitute unlimited delegation. A bare flag, partial answer, generic "yes", assistant inference, or pointing at an unanswered document cannot resolve a material question. Wrong/missing actor/outcome/scope/provenance leaves the request blocked with diagnostic. Resolved means this requested contribution is recorded, not implementation, verified truth, approval, acceptance, or completed grilling.

### Authoritative projections and deferral overlays

The stable identity tuple is `(realpath project root, full issue ID, source_key)`. Normalized source keys:

- `human_input:<request-id>`: authority is that request.
- `human_checks:<check-id>`: authority is existing human_checks entry; reject duplicates, retain its existing statuses pending/passed/failed, revision/result and evidence/judgment kind. No editable copied result in human_input.
- `acceptance:issue`: authority is project's explicit acceptance/closure handler and rules. Before acceptance, expose a pending contribution only when the adapter establishes relevant work/evidence readiness; no stored synthetic pass. Closed-without-implementation stays an explicit administrative closure with its actual reason, never fabricated verification.
- `factory-approval:<action-uuid>`: Timey-owned candidate approval authority, bound to exact repository, candidate commit and target basis. A changed candidate or changed approved integration diff needs approval again.
- `legacy-grill-later:issue`: compatibility projection only while old whole-issue parking applies.

Each source has a `source_revision` digest of its authoritative content plus revision/candidate identity. A human check is not a second human_input request. Projection interactions route to its owner handler: record check result in human_checks, approval in factory-owned candidate approval data, acceptance through explicit closure/acceptance rules. Shared apply must reject attempts to mutate these authorities.

A selected projected request can be deferred without forging its result. Store only presentation disposition as an overlay `{source_key, source_revision, status: deferred|active, events:[...]}` in human_input.overlays. No outcome/pass/answer field permitted there. An overlay applies only to the referenced source_revision; a changed source drops its active disposition and shows a stale-overlay diagnostic. Pending/failed human check remains blocking while deferred. Deferred acceptance remains unaccepted. Native request deferral uses its own status/events, not an overlay. Unknown sources are diagnostic, never quietly transformed into independent requests.

Legacy human_checks without IDs or malformed classifications: diagnose; do not assign positional identities or infer passed evidence. Existing Timey valid IDs are reused unchanged. Agent must review old code/evidence applicability even if recorded status is passed. Changed affected code invalidates evidence; hash equality cannot establish device truth.

### Grilling record

```yaml
grilling:
  version: 1
  status: unassessed                 # unassessed | not-needed | recommended | in-progress | completed | stale
  scope: {id: main, revision: 1}
  reason: "Why this assessment applies"
  material_request_ids: [scope-choice]
  decision_refs: []
  confirmation: null
  history: []
```

All keys required if grilling exists; only unassessed can have null scope and empty reason (when no assessed scope exists). `material_request_ids` are local native requests; other authoritative requirements remain separate. Completed requires current scope, all identified material questions actually settled (valid current outcomes), nonempty decision_refs, and confirmation `{actor: human, evidence_ref, summary, scope:{id,revision}}` recording the person's shared-understanding confirmation. Agent verifies coverage beyond the enumerated list; an empty list cannot hide open prose decisions. Delegation can settle a suitable material choice but cannot supply this confirmation. Grilling neither approves code nor completes checks/acceptance. A session invocation or answer to one group member cannot mark all completed.

Not-needed requires a current scope and concrete reason why no interview is needed; confirmation and decision_refs may be absent/null/empty as specified, never invent completion. Recommended/in-progress are optional unless concrete material requests declare gates. If conclusions cease to cover current material scope, append prior assessment including its actual evidence/confirmation to history, set stale, reopen only affected requests (keep earlier outcomes in events/history), and advance affected scope revision. History entries are full prior assessment without nested history plus `superseded_at` and `reason`. A not-needed assessment also becomes stale on affected material change. Bookkeeping edits, formatting, links repaired without changed meaning, and progress notes alone do not invalidate scope. Human input on an unrelated scope does not erase current decisions in another scope.

### Legacy grill_later

`grill_later: true` retains whole-issue parking and existing fixer/Timey launch behavior until explicit resume or a justified, human-directed mapping to named deferred requests. Missing metadata does not unpark it. Listing projects the legacy parked contribution without writing. Migration atomically records the mapping rationale/evidence, creates or identifies affected native deferred requests with the same substantive gates, and clears the global flag; unrelated new requests then follow their own gates. A plain new request or completed grilling flag does not perform this migration. Keep the legacy `go`/resume meanings within existing authority; never treat them as human-only evidence or silent permission to drop unresolved decisions.

## 3. Readiness and freshness

The shared helper provides structural normalization, diagnostics and declared blockers, not final permission. It never interprets arbitrary report text as instructions, proves human truth, detects every material prose change, decides whether an old interview fits, or grants implementation authority. The agent checks actual answers/coverage, affected code/revisions, semantic dependencies, human source, lifecycle exit conditions, current candidate diff, selected scope and original authorization at every dispatch.

### Operation behavior

| Situation | Progress with a consuming policy override | Merge / record-integration | Accept / verified closure |
| --- | --- | --- | --- |
| Required scope choice open/partial/deferred | Block declared affected work | Block when declared dependent | Block any required unresolved work |
| Optional grilling, no material gates | Eligible after ordinary review | Ordinary checks still apply | Never counts as acceptance |
| Mapped human check pending/failed, dependent-work | Block dependent implementation and downstream verification/commit/merge/integration that rely on it; unrelated investigation stays eligible | Block dependent candidate | Block when required for completion |
| Judgment mapped to closure only | Allow verified progress | Allow relevant verified integration | Block |
| Shared default requires all manual checks before commit | Preserve default until consuming policy explicitly overrides | Preserve applicable requirements | Block required checks |
| Prerequisite not ready | Show upcoming human task; gates remain | Same | Same |
| Unsupported/malformed new metadata | Block affected issue/operation and return useful diagnostic | Same | Same |
| No new metadata | Semantic review required; no invented blocker | Reassess existing reports/checks/policy | Explicit acceptance still required |

Callers supply exact operation plus affected issue/scope IDs and trusted project policy. Default context is whole issue (`*`), so a caller cannot accidentally evade a gate by omitting scope. Narrower context requires a recorded scope justification and dependency review by the agent. Project-specific checks map to operations in one trusted adapter; reports cannot replace this policy. A failed readiness prerequisite never turns an unresolved gate into ready. Cross-issue dependencies resolve by full ID + source key and outcome, never lifecycle/triage_role alone. Advancing state evaluates source exit conditions AND the target operation's prerequisites; pure metadata naming cannot skip human obligations. Explicit administrative close retains current user semantics and records unverified closure; it must not emit an accepted-and-verified result.

Action freshness: compute SHA-256 of exact report bytes (including YAML, body, comments, BOM/newlines), plus lifecycle, preferences and adapter-policy digests; bind canonical project, full ID, source_key, source_revision, saved lifecycle/request status, operation and target state/candidate. Re-read immediately before any mutation/dispatch. Same state and same timestamp cannot satisfy a changed report token. External authority digest (factory candidate etc.) must also match. Old actions fail without writes; refresh. Update of updated timestamp alone is neither sufficient nor necessary to detect edits.

Semantic freshness: use stable `(scope id, revision)` and recorded current-scope evidence; a changed byte digest invalidates old buttons/Quick fix assessments, not automatically grilling. On dispatch the agent reviews intervening material changes and supplies an applicability attestation tied to current report digest and affected scope revisions. Explicit mismatch is stale even if text hash later returns to an old value. Listing can show `recorded_status: completed, currentness: needs-review` until reviewed, without declaring it current or silently reopening it. Reopening/history requires an authorized reviewed update. Scope numbers do not detect an unmarked direct material edit; agent responsibility remains explicit.

Quick fix v2 metadata adds `version: 2`, `basis_digest`, `policy_digest`, and `scope` to existing state/assessed_updated/reason. `basis_digest` hashes exact report bytes with only the entire quick_fix YAML node removed (use a YAML CST range, preserve all other bytes); this avoids self-hashing. Existing v1 assessments become review-required, no Quick fix button until reassessed; work-on-issue remains available. The action token still hashes the full final report including assessment. New input/body edits at identical state/timestamp invalidate v2 assessment. External code/evidence changes still require dispatch review even if report digest is unchanged.

## 4. Versioned installed helper and guarded update boundary

Introduce source `src/human-input.ts` (pure normalization/projection/gates/token calculation), `src/queue-io.ts` (safe report resolution/CST narrow writes/lifecycle utility), `src/human-input-cli.ts` (JSON boundary). Export no development checkout paths to consumers.

Every standalone queue skill bundles `scripts/human-input.mjs` plus YAML license and `scripts/human-input-version.json`. Manifest: `{protocol:"local-issues-human-input/1", implementation_version:"1.0.0", source_revision:<shared commit built>, bundle_sha256:<helper bytes>}`. Version manifest is generated after bundle, so no circular hash. Build source_revision must be supplied explicitly for staged/exported candidates; a release manifest binds actual resulting candidate commit through external evidence when commit embeds generated output. Do not pretend an uncommitted generated file was built from a later commit. A source tree digest excluding generated outputs is also recorded as `source_tree_digest` to identify exact precommit build input. Consumers require protocol major 1 and compatible capabilities, not a guessed installed version.

Installed path: `<selected-queue-skill>/scripts/human-input.mjs`; not an npm global package, sibling import, daemon or private source import. Node 22+; bundled YAML, no network/runtime npm install. A later consuming adapter may select an explicit absolute path using `LOCAL_ISSUES_HELPER` or its documented installed path. That adapter must check capabilities/manifest/protocol/hash, report missing/incompatible bundles, and retain its exact selected version. No Timey adapter is included in this shared core. Other standalone skills use their own bundle. They do not need issues installed. All four copies must be byte-identical for a release.

CLI v1:

```text
node <skill>/scripts/human-input.mjs capabilities
node <skill>/scripts/human-input.mjs read --project ABS --context ABS.json
node <skill>/scripts/human-input.mjs apply --project ABS --context ABS.json --intent ABS.json
```

`capabilities`: `{protocol,implementation_version,capabilities:["read","native-update","add-request","projection-disposition","guards"],source_tree_digest,bundle_sha256}`. `read` reads only, emits exactly one JSON object on stdout, diagnostics inside JSON; never creates queue/config/lock. Absent queue returns empty issues with `QUEUE_ABSENT` informational diagnostic. No source import side effects. Context file has `{protocol,operation,issue_ids,scope_ids,target_state?,candidate?,policy,adapter_facts,semantic_reviews}`. issue_ids are full IDs; listing can pass empty list to read all. `operation: "view"` is accepted only for read and computes presentation, not dispatch eligibility. policy is a named trusted adapter schema with `id`, `version`, `digest`, mapped human-check gates, lifecycle/commit/acceptance requirements; unsupported adapter extensions fail closed. Built-in shared policy is available when no consuming adapter is provided. adapter_facts are explicit owner-derived source records including source_key/source_revision/status/readiness/evidence refs, never pulled from report instructions. semantic_reviews contain reviewer/provenance, current report digest, affected scope revisions and applicability verdict; their content still requires a real agent review, not fabricated normalization.

Read-model shape (all lists always present):

```json
{
  "protocol": "local-issues-human-input/1",
  "implementation_version": "1.0.0",
  "project_root": "/canonical/project",
  "operation": "implement",
  "policy_digest": "sha256:...",
  "issues": [{
    "id": "full-id", "path": "/canonical/project/.issues/full-id.md", "state": "in-progress",
    "report_digest": "sha256:...", "configuration_digest": "sha256:...",
    "grilling": {"recorded_status":"unassessed","currentness":"needs-review","scope":null},
    "requests": [{
      "source_key":"human_input:scope-choice", "source_revision":"sha256:...",
      "authority":"human_input", "kind":"decision", "prompt":"...", "expected":"...",
      "scope":{"id":"main","revision":1}, "status":"pending", "disposition":"active",
      "availability":"now", "prerequisites":[], "blocks":["implement"],
      "evidence_refs":[], "actions":["answer","grill","defer"],
      "guard":{"project_root":"/canonical/project","id":"full-id","source_key":"human_input:scope-choice","source_revision":"sha256:...","report_digest":"sha256:...","configuration_digest":"sha256:...","policy_digest":"sha256:...","expected_state":"in-progress","expected_status":"pending","operation":"implement","target_state":null,"candidate":null}
    }],
    "blockers":[{"source_key":"human_input:scope-choice","operation":"implement","code":"INPUT_REQUIRED","message":"..."}],
    "structurally_eligible":false, "semantic_review_required":true, "diagnostics":[]
  }],
  "diagnostics":[]
}
```

Availability enum `now|upcoming|deferred|unknown`; disposition `active|deferred`; currentness `current|stale|needs-review|unassessed`; blockers retain source identity, operations and affected scope IDs in full output (example abbreviated). `structurally_eligible: true` is expressly not permission or proof. Group candidates include selected keys and explanation only, never a group-level completed flag.

`apply` accepts `{protocol,operation_id,updates:[...]}`. Each update contains guard from a fresh read, `action` from `add-request|start|record-partial|resolve|defer|resume|assess-grilling|reopen|map-legacy|set-disposition`, and the corresponding typed fields/events/outcome/assessment. Arbitrary YAML patch paths and edits to state, human_checks, approval, acceptance or source files are rejected. Existing owner handlers perform those operations using the same guard verification. Native updates may initialize metadata only as part of an explicit selected action with justified evidence; no opportunistic migration. Source IDs cannot change through updates.

For `resolve`, validate full expected contribution coverage and current scope, require nonempty actual outcome/provenance, and require agent-reviewed applicability tied to fresh digest; structural checks cannot establish truth. For partial, append event, retain pending/in-progress. For assess-grilling completed enforce above checks. For grouped outcomes: deduplicate source IDs; conflicting duplicate operations are invalid per report. Prevalidate all selected requests sharing a report against ONE current snapshot, build one CST patch, write that report once. This prevents the first answer from falsely staling the second. Report groups are independent; skip stale/blocked/missing files and continue eligible files, return per-source outcomes, refresh once. No all-queue transaction claim.

Mutations acquire a project-local exclusive mkdir lock `.issues/human-input.lock`, refuse uncertain existing locks with reconciliation advice (do not auto-delete). Re-read after acquiring and just before replacing; stage same-directory temp then atomic rename, release only owned lock. Preserve unrelated YAML comments/prose/bytes using CST node edits plus append-only response sections; unsupported YAML forms fail rather than whole-document dump. Reject symlinks, path escape, ambiguous filename IDs, duplicate IDs/keys, nonregular files. Arbitrary external editors do not obey the lock: optimistic compare plus atomic rename does NOT make read/check/write atomic against a racing editor; document this limit, detect observable races, keep the captured basis/recovery evidence and stop rather than overwriting known changes. No claim of crash-safe multi-file transaction.

`operation_id` is a unique UUID per explicit response action; successful updates persist a bounded audit event carrying it in the report. A retry whose ID is already applied returns `already-applied` with no write; mismatched payload for reused ID returns `DUPLICATE_CONFLICT`. Old digest naturally catches duplicate stale buttons too. Per-request action tokens are not security signatures; authorization remains the actual user action and trusted agent dispatcher. Browser/report-supplied actor strings are not credentials.

Output apply: `{protocol,operation_id,results:[{id,source_key,status:"applied|already-applied|stale|blocked|invalid|missing|error",code?,message?,new_report_digest?}],diagnostics:[]}`. Exit 0 all selected successful/no-op; 2 malformed CLI/JSON/protocol; 3 missing/incompatible helper policy/runtime capability (consumer blocker); 4 any structural blocked/invalid/stale/missing request, including partial batches; 5 lock/conflict/IO failure. A read returning declared blockers is exit 0 with structurally_eligible false; callers MUST read it, not use exit 0 as readiness. A read with malformed affected metadata exits 4 but still emits model/diagnostics for independent valid issues. Native CLI always returns JSON for handled errors, stderr reserved for runtime debugging, no report contents/secrets printed.

Stable error codes: `PROTOCOL_UNSUPPORTED`, `POLICY_UNSUPPORTED`, `QUEUE_ABSENT`, `REPORT_MISSING`, `REPORT_INVALID`, `DUPLICATE_ID`, `SOURCE_MISSING`, `SOURCE_INVALID`, `SCOPE_STALE`, `OUTCOME_INCOMPLETE`, `HUMAN_AUTHORITY_REQUIRED`, `OWNER_UPDATE_REQUIRED`, `PREREQUISITE_UNMET`, `INPUT_REQUIRED`, `LEGACY_PARKED`, `STALE_ACTION`, `DUPLICATE_CONFLICT`, `LOCKED`, `PATH_UNSAFE`, `IO_FAILURE`. Include issue/source/path where safe; malformed metadata with unknown block scope conservatively blocks that issue's mutating/dispatch operations, not unrelated reports or read-only listing. Missing/incompatible helper blocks new guarded mutations; allow read-only diagnostic fallback, never substitute a divergent parser for dispatch.


## Interface precision

All digest fields use `sha256:` followed by 64 lowercase hexadecimal digits, computed over UTF-8 bytes for JSON/config encodings and original raw bytes for files. Canonical JSON means recursively sorted object keys, array order retained, no insignificant whitespace; undefined/NaN are invalid. `configuration_digest` hashes canonical JSON of lifecycle/preferences raw-file digests (missing file represented explicitly). `policy_digest` hashes the entire canonical trusted policy object excluding its digest field. `source_revision` hashes canonical normalized authority content including its scope/code/candidate revision, excluding presentation overlays and derived diagnostics. `report_digest` includes all report bytes, not normalization. A capability response's bundle hash is the actual executing bundle bytes; the manifest is adjacent and must agree.

`human_input.scopes` must exist for any non-null grilling scope; initializing an assessment without earlier human_input creates the explicitly reviewed minimal scope record. Unknown keys are preserved at storage boundaries but unknown enum/version/control fields cannot grant readiness. `events[].operation_id` and `events[].payload_digest` are optional for historical/directly authored events and required for helper-applied events; they implement duplicate protection. Canonical update-payload digest excludes guard digests and operation_id, so an exact retry can be recognized before stale-token failure, while changed content with a reused operation ID is a conflict. Check already-applied against the recorded per-source event only; group retry returns applied/already-applied independently. Do not treat a UUID found in arbitrary prose as an applied update.

Context policy shape:

```json
{
  "id":"example", "version":1,
  "human_checks":{
    "dependent-work":["implement","verify","commit","merge","record-integration","accept","close"],
    "closure":["accept","close"]
  },
  "check_scope_default":"*",
  "require_explicit_acceptance":true,
  "manual_checks_before_commit":false,
  "acceptance_role":"ready-to-close",
  "closed_role":"closed"
}
```

`manual_checks_before_commit:false` is an example consuming override, not a new shared default. Shared-default v1 uses true. Narrowing a dependent-work check for unrelated work requires adapter fact `{source_key,source_revision,applies_to_scope_ids,evidence_refs}` reviewed against its actual instructions/code; absent scope applicability is all scopes, not empty. Adapter facts may additionally expose `{source_key,source_revision,authority,kind,status,prompt,expected,prerequisites,blocks,availability,evidence_refs,candidate}` for owner projections. `candidate` is `{repository_root,action_id,revision,target_revision}`; all revisions are exact commits. Missing candidate facts do not create a ready approval task. Work-ready/evidence-ready/candidate-ready prerequisites consume owner facts with matching source_revision and evidence; resolved/passed consume normalized current authoritative outcomes. A matching status without required evidence is unsatisfied.

Read context also always includes `issue_ids`, `scope_ids`, `adapter_facts` and `semantic_reviews` arrays. Empty scope_ids on `view` means all; empty/missing scope_ids on a dispatch operation is normalized to `["*"]`, never no gates. `target_state` is required for advance and forbidden when irrelevant. Full candidate tuple required for merge, record-integration or factory-approval mutation routing. Context paths are local data, not executable modules. Trusted caller supplies policy; the table may carry its digest but cannot select a weaker policy.

Concrete native apply payload (abbreviated hashes stand for full valid digests in actual use):

```json
{
  "protocol":"local-issues-human-input/1",
  "operation_id":"a75a109d-ff26-445b-b6fd-c8696f035227",
  "updates":[{
    "guard":{
      "project_root":"/canonical/project", "id":"full-id",
      "source_key":"human_input:scope-choice", "source_revision":"sha256:...",
      "report_digest":"sha256:...", "configuration_digest":"sha256:...", "policy_digest":"sha256:...",
      "expected_state":"in-progress", "expected_status":"pending", "operation":"implement",
      "target_state":null, "candidate":null
    },
    "action":"record-partial",
    "event":{
      "id":"partial-01", "type":"partial", "at":"2026-10-23T12:00:00Z", "actor":"human",
      "summary":"Answered the first fragment; second remains open.",
      "evidence_refs":["conversation:actual-human-answer"]
    }
  }]
}
```

Update field rules: start requires started event; record-partial requires partial event; resolve requires answered/delegated event plus complete outcome and semantic_review; defer requires deferred event; resume requires resumed event; assess-grilling requires full assessment plus scope-reviewed event and semantic_review; reopen requires reopened event, reason, affected scope/request IDs and semantic_review (old outcome preserved); map-legacy requires human authorization ref, explicit old-to-new source mapping, full native request additions as necessary, reason and scope-reviewed event; set-disposition requires exact projected source_revision plus active/deferred disposition and resumed/deferred event. Any inconsistent event/action/type/actor is invalid. Native additions require an explicit reviewed source identity, full request shape and source-missing guard bound to fresh report bytes; expose this as `action: "add-request"` in CLI capabilities and read-only command documentation. Add-request is not permitted to overwrite an existing ID, create human-check/acceptance/approval authority, or backfill in listing. Version 1 capabilities therefore include `add-request` alongside the earlier feature groups. `apply` reads trusted context/policy from its required --context file (same schema as read), never a weaker policy from the browser payload.

Guard operation names the downstream operation being assessed; action names the selected response interaction. Fresh token matching does not authorize a different interaction: dispatch verifies the user's actual selected action, target source(s), proposed event/outcome, and whether continuation was explicitly requested. `semantic_review` in an update is `{reviewer:"agent",evidence_ref,report_digest,scope:{id,revision},verdict:"applicable|material-change",reason}`; material-change must name reopened affected sources and new scope revision in the patch. Ordinary complete answers use applicable after reviewing current scope. An external direct edit is not trusted merely because it supplied this shape.

For add-request, guard source_revision and expected_status are null and source_key names the new native request ID; its absence is rechecked under lock. The payload includes full `request` and optional `scope_definition` matching scopes[] for a new scope. Creating a scope with an existing ID or overwriting a source is invalid. Additions require actual dispatch authorization and current report/config/policy digests just as updates do. The UI exposes only supported actions returned by capabilities and validated read-model; unknown actions never become arbitrary patch verbs.


## Dispatch procedure

Before ordinary work, concrete feedback edits, Quick fix, lifecycle advance, grouped/batch actions, verified closure, commit, merge or recording integration, run a fresh helper read for the exact operation, IDs and scopes using trusted current project policy and owner facts. Require no structural blockers, then review the source evidence, current code, lifecycle exit conditions and actual selected user action. Before the owner mutation, reread and compare the entire guard including authority/candidate revision. The owner handler must enforce those guards; shared apply cannot mutate lifecycle or source. Quick fix expands to implement, verify, commit when enabled, and each intended advance; check each separately. An old table request carrying only expected state is an instruction to obtain a fresh guard, never a freshness token.

A scoped dispatch needs a recorded current semantic dependency review before narrower scopes are usable. Empty scope IDs mean all scopes for dispatch. Unavailable prerequisites still block declared dependent work. Independent work remains eligible only after the agent verifies independence. Work-ready/evidence-ready/candidate-ready facts are owner-supplied, current and evidence-backed; report booleans cannot establish them.

Read-only listing preserves all report bytes. Missing metadata means unassessed and semantic review required. Recommended grilling has no implicit gates. A partial answer stays open; a delegated choice needs actual human authorization and bounds and cannot create device evidence, shared-understanding confirmation, candidate approval or acceptance. Directly edited answers receive the same coverage and applicability review. No pass or completion follows merely from a flag or document pointer.

Native updates use one operation UUID per explicit response, exact guard, typed event and selected outcome. On partial batches report each result and refresh once. Never mark a whole group complete because one member answered. Mapping legacy parking requires human authorization, scope definitions if absent, explicit old-to-new mapping and deferred native requests preserving its whole-issue gates. Clearing legacy parking through an existing owner resume handler must preserve outstanding material obligations.

The lock serializes cooperating helpers only. External editors can race between the final byte comparison and rename. The helper detects observable changes and removes its owned temporary file; retain the original read/intent outside the queue as recovery evidence. An uncertain lock requires owner reconciliation; no automatic lock stealing or crash-safe multi-report transaction is claimed. No live host behavior, user provenance or physical truth is established by helper tests.


### Shared core implementation notes

The helper persists append-only helper audit events in the selected native request/overlay. Assessment audit events are retained in `grilling.events`; prior full assessments remain in `grilling.history` without nested history. Legacy mapping records source-keyed events on its named native targets so retries remain bound to the original legacy source even after global parking clears. These audit extensions never grant readiness. Resolve and assessment actions require `semantic_review.verdict: applicable`; material-change verdict belongs to an explicit reopen patch. New native additions begin unresolved and use a separate fresh resolve action.

Source-tree digest inventory is the authored runtime/tooling, canonical protocol, and queue-skill instructions/assets named in `scripts/source-tree.mjs` at build time; generated copies, evidence logs and unrelated standalone skills are excluded. The source revision is the actual explicit build-basis commit. External review evidence identifies the resulting candidate commit separately.
